$('.unassigned-box').click(function(){
	$('.load-details-page').addClass('active');
});
$('.closeBtn').click(function(){
	$('.load-details-page').removeClass('active');
});
