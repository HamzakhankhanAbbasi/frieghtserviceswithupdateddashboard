<!-- Login Pop modal -->

<div class="modal fade" id="forgetmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="forgetmodalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content contact-modal ">
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      <div class="modal-body">
        <div class="forget-popup login-rightwrap">
          <p class="pink-text">Contact Us</p>
          <form class="row g-3 mt-3">
			<div class="col-md-12">
				<input type="text" class="form-control" id="inputName4" placeholder="Name">
			</div>
			<div class="col-md-12">
				<input type="Email" class="form-control" id="inputEmail4" placeholder="Email">
			</div>
			<div class="col-12">
				<input type="text" class="form-control" id="inputAddress" placeholder="Phone no.">
			</div>
			<div class="col-12">
			    <textarea placeholder="add comments"></textarea>
			</div>
			<div class="col-12 inquireBtn">
				<a href="#!">Contact Now</a>
			</div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
	<!-- view-load-div-start -->
		    <div class="load-details-page">
				<div class="row">
					<div class="col-12 col-md-6 col-lg-6">
						<div class="load-p-left">
							<button type="button" class="closeBtn">
								<i class="fas fa-times"></i>
							</button>
							<div class="unassigned-box">
								<div class="box-s1">
									<a href="#!">Martin</a>
									<div class="bx-text-sec">
										<p class="pink-text">42 lbs</p>
										<p class="pink-text">$ 50.00</p>
										<p class="grey-text">197ml</p>
									</div>
								</div>
								<div class="box-s2">
									<a href="#!"><i class="fas fa-map-marker-alt"></i></a>
									<div class="box-s2-inner">
										<p class="pink-text">497 Evergreen RD. Rosevilla,</p>
										<p class="grey-text">01 Jan 18:00 CST</p>
									</div>
								</div>
								<div class="box-s2 bx-3">
									<a href="#!"><i class="fas fa-dot-circle"></i></a>
									<div class="box-s2-inner">
										<p class="pink-text">497 Evergreen RD. Rosevilla,</p>
										<p class="grey-text">01 Jan 18:00 CST</p>
									</div>
								</div>
								<!-- <div class="inquireBtn">
									<a href="#!">inquire</a>
								</div> -->
							</div>
							<div class="commodity-sect">
								<p class="loadP-bold-text">Commodity</p>
								<div class="com-inner-sect">
									<div class="type">
										<p>Truck Type</p>
										<a href="#!">Lorem ipsum</a>
									</div>
									<div class="type">
										<p>Commodity</p>
										<a href="#!">Lorem ipsum</a>
									</div>
								</div>
								<div class="com-inner-sect">
									<div class="type">
										<p>Packing Type</p>
										<a href="#!">Lorem ipsum</a>
									</div>
									<div class="type">
										<p>Weight</p>
										<a href="#!">Lorem ipsum</a>
									</div>
								</div>
							</div>
							<div class="commodity-sect commentarea">
							    <p class="loadP-bold-text">Comments</p>
							    <div class="col-12">
                    			    <p class="grey-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum vero earum rerum voluptatibus quae? Perspiciatis.</p>
                    			</div>
							</div>
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6">
						<div class="load-p-right">
							<div class="map-image">
								<img src="assets/images/map-image.png" class="img-fluid" alt="">
							</div>
							<div class="path-image">
								<img src="assets/images/path-image.png" class="img-fluid" alt="">
							</div>
							<div class="map-inprocess-btn">
								<a href="#!">In-Process</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		<!-- view-load-div-end -->
		<!-- searchbar-modal-click-start -->
		<div id="FullScreenOverlay" class="overlaySearch">
  		<span class="closebtn" onclick="closeSearchHero()" title="Close overlaySearch">×</span>
		<div class="overlay-content">
			<form action="">
				<div class="fieldWrapper">
					<input type="text" class="modalInput" placeholder="Search" name="search">
					<button type="submit" class="modalBtn gen-gradient"><i class="fa fa-search"></i></button>
				</div>
			</form>
		</div>
	</div>
		<!-- searchbar-modal-click-end -->

<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>
